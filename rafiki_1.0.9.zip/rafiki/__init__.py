# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Rafiki",
    "author" : "Riganon - Shawn Blanch and Phil Osterbauer", 
    "description" : "Project and Asset Management",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 9),
    "location" : "VIEW3D Tool",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy.app.handlers import persistent
import shutil


addon_keymaps = {}
_icons = None
g_op_file_browser = {'sna_var_temp_byte_string_path': '', 'sna_var_window': None, }


g_op_import_file = {'sna_var_temp_file_path': '', }
g_op_import_image = {'sna_var_temp_image_path': '', }
g_op_import_video = {'sna_var_temp_file_path': '', }
g_op_new_temp_file_browser = {'sna_temp_render_x': 0, 'sna_temp_render_y': 0, 'sna_temp_render_display': '', 'sna_temp_render_slot_name': '', 'sna_render_slot_exists': False, }


g_scripts = {'sna_image_ext_list': [], 'sna_video_ext_list': [], 'sna_importable_ext_list': [], }


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def find_biggest_area_by_type(screen, area_type):
    areas = find_areas_of_type(screen, area_type)
    if not areas: return []
    max_area = (areas[0], areas[0].width * areas[0].height)
    for area in areas:
        if area.width * area.height > max_area[1]:
            max_area = (area, area.width * area.height)
    return max_area[0]


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_update_sna_current_folder_B9271(self, context):
    sna_updated_prop = self.sna_current_folder
    if bool(sna_updated_prop):
        if os.path.isdir(sna_updated_prop):
            sna_fn_reset_collection_9C2D0(sna_updated_prop, '')


def sna_update_sna_rafiki_projects_folder_28569(self, context):
    sna_updated_prop = self.sna_rafiki_projects_folder
    bpy.context.scene.sna_template_projects_collection_index = -1
    bpy.context.scene.sna_rafiki_projects_collection.clear()
    if os.path.isdir(bpy.path.abspath(sna_updated_prop)):
        item_9372D = bpy.context.scene.sna_rafiki_projects_collection.add()
        item_9372D.project_name = os.path.basename(os.path.dirname(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)))
        item_9372D.project_folder = bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)
        for i_F5984 in range(len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)) if os.path.isdir(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f))])):
            item_25A51 = bpy.context.scene.sna_rafiki_projects_collection.add()
            item_25A51.project_name = os.path.basename(bpy.path.abspath([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)) if os.path.isdir(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f))][i_F5984]))
            item_25A51.project_folder = bpy.path.abspath([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)) if os.path.isdir(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder), f))][i_F5984])


def sna_update_folder_name_9CB54(self, context):
    sna_updated_prop = self.folder_name
    if bool(sna_updated_prop):
        if (sna_updated_prop != os.path.basename(self.folder_directory)):
            old_folder_path_with_name = self.folder_directory
            new_folder_name = sna_updated_prop
            new_folder_path_with_name = None
            new_folder_path_with_name = rename_folder(old_folder_path_with_name,new_folder_name)
            self.folder_directory = new_folder_path_with_name
            bpy.ops.sna.rafiki_refresh_project_folder_af53a('INVOKE_DEFAULT', )


class SNA_UL_display_collection_list_01EE6(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_01EE6, icon, active_data, active_propname, index_01EE6):
        row = layout
        layout_function = layout
        sna_ui_fn_diplay_collection_loop_item_117F9(layout_function, item_01EE6, index_01EE6)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if sna_fn_active_projects_filter_ED2A1(item):
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


class SNA_UL_display_collection_list001_B1951(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_B1951, icon, active_data, active_propname, index_B1951):
        row = layout
        if (index_B1951 == 0):
            op = layout.operator('sna.rafiki_22387', text=item_B1951.project_name, icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=True, depress=False)
            op.sna_base_folder = os.path.dirname(os.path.dirname(item_B1951.project_folder))
            op.sna_project_name = item_B1951.project_name
        else:
            op = layout.operator('sna.rafiki_22387', text=item_B1951.project_name, icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=True, depress=False)
            op.sna_base_folder = os.path.dirname(item_B1951.project_folder)
            op.sna_project_name = item_B1951.project_name

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if sna_fn_display_projects_B0A0A(item):
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_D5355(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_D5355, icon, active_data, active_propname, index_D5355):
        row = layout

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


def sna_fn_recursive_folders_9793D(Path, Prefix):
    if os.path.exists(Path):
        for i_9CBCB in range(len([os.path.join(Path, f) for f in os.listdir(Path)])):
            item_32F4D = bpy.context.scene.sna_active_project_collection.add()
            item_32F4D.prefix = Prefix
            item_32F4D.folder_directory = [os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]
            item_32F4D.folder_name = os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB])
            if os.path.isdir([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]):
                item_32F4D.is_directory = True
                print('🐒 Folder: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))
                sna_fn_recursive_folders_9793D([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB], ' ' + Prefix)
            else:
                if (os.path.splitext([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB])[1] == '.blend'):
                    item_32F4D.is_blend_file = True
                    print('🐒 Blend file: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))
                else:
                    if os.path.splitext([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB])[1] in g_scripts['sna_video_ext_list']:
                        item_32F4D.is_video_file = True
                        print('🐒 Video: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))
                    else:
                        if os.path.splitext([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB])[1] in g_scripts['sna_image_ext_list']:
                            item_32F4D.is_image_file = True
                            print('🐒 Image: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))
                        else:
                            if os.path.splitext([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB])[1] in g_scripts['sna_importable_ext_list']:
                                item_32F4D.is_importable_file = True
                                print('🐒 Importable: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))
                            else:
                                item_32F4D.is_other_file = True
                                print('🐒 File: ', Prefix + os.path.basename([os.path.join(Path, f) for f in os.listdir(Path)][i_9CBCB]))


def sna_fn_reset_collection_9C2D0(Path, Prefix):
    bpy.context.scene.sna_active_project_collection.clear()
    sna_fn_recursive_folders_9793D(Path, Prefix)


@persistent
def load_pre_handler_1A3F2(dummy):
    bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder


class SNA_OT_Rafiki_Add_Folder_To_Asset_Libraries_3271A(bpy.types.Operator):
    bl_idname = "sna.rafiki_add_folder_to_asset_libraries_3271a"
    bl_label = "Rafiki Add Folder to Asset Libraries"
    bl_description = "Adds the folder to the asset library"
    bl_options = {"REGISTER", "UNDO"}
    sna_directory: bpy.props.StringProperty(name='directory', description='', default='', subtype='DIR_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.isdir(bpy.path.abspath(self.sna_directory)):
            bpy.ops.preferences.asset_library_add(directory=bpy.path.abspath(self.sna_directory))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Select_Asset_Library_4Acf6(bpy.types.Operator):
    bl_idname = "sna.rafiki_select_asset_library_4acf6"
    bl_label = "Rafiki Select Asset Library"
    bl_description = "Set the Asset Library to the Folder"
    bl_options = {"REGISTER", "UNDO"}
    sna_directory: bpy.props.StringProperty(name='directory', description='', default='', subtype='DIR_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.isdir(bpy.path.abspath(self.sna_directory)):
            if (property_exists("bpy.context.preferences.filepaths.asset_libraries", globals(), locals()) and os.path.basename(bpy.path.abspath(self.sna_directory)) in bpy.context.preferences.filepaths.asset_libraries):
                if (bpy.path.abspath(bpy.context.preferences.filepaths.asset_libraries[bpy.context.preferences.filepaths.asset_libraries.find(os.path.basename(bpy.path.abspath(self.sna_directory)))].path) == bpy.path.abspath(self.sna_directory)):
                    if bool(find_areas_of_type(bpy.context.screen, 'FILE_BROWSER')):
                        if (find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').ui_type == 'ASSETS'):

                            def delayed_A6533():
                                find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').spaces[0].params.asset_library_reference = os.path.basename(bpy.path.abspath(self.sna_directory))
                            bpy.app.timers.register(delayed_A6533, first_interval=0.10000000149011612)
                        else:
                            window_0_f7f62 = sna_new_window_resizable_5AAD0(1024, 512, 'Assets')

                            def delayed_71C1F():
                                window_0_f7f62.screen.areas[0].spaces[0].params.asset_library_reference = os.path.basename(bpy.path.abspath(self.sna_directory))
                            bpy.app.timers.register(delayed_71C1F, first_interval=0.10000000149011612)
                    else:
                        window_0_c021b = sna_new_window_resizable_5AAD0(1024, 512, 'Assets')

                        def delayed_94F31():
                            window_0_c021b.screen.areas[0].spaces[0].params.asset_library_reference = os.path.basename(bpy.path.abspath(self.sna_directory))
                        bpy.app.timers.register(delayed_94F31, first_interval=0.10000000149011612)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Copy_Folder_2F5D3(bpy.types.Operator):
    bl_idname = "sna.rafiki_copy_folder_2f5d3"
    bl_label = "Rafiki Copy Folder"
    bl_description = "Copy folder(s) from one directory to another"
    bl_options = {"REGISTER", "UNDO"}
    sna_source: bpy.props.StringProperty(name='source', description='', default='', subtype='DIR_PATH', maxlen=0)
    sna_destination: bpy.props.StringProperty(name='destination', description='', default='', subtype='DIR_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        source_dir = bpy.path.abspath(self.sna_source)
        destination_dir = bpy.path.abspath(self.sna_destination)
        copy_folder_directory(source_dir,destination_dir)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Copy_Folder_And_Create_Rafiki_Project_D48E1(bpy.types.Operator):
    bl_idname = "sna.rafiki_copy_folder_and_create_rafiki_project_d48e1"
    bl_label = "Rafiki Copy Folder and Create Rafiki Project"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_source: bpy.props.StringProperty(name='source', description='', default='', subtype='DIR_PATH', maxlen=0)
    sna_dest: bpy.props.StringProperty(name='dest', description='', default='', subtype='DIR_PATH', maxlen=0)
    sna_rafiki_project: bpy.props.StringProperty(name='rafiki_project', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sna.rafiki_copy_folder_2f5d3('INVOKE_DEFAULT', sna_source=self.sna_source, sna_destination=self.sna_dest)
        bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder = self.sna_rafiki_project
        bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = self.sna_rafiki_project
        bpy.context.scene.sna_active_project_collection_index = -1
        self.report({'INFO'}, message='🐒 Rafiki: ' + 'Project Folder ' + bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Create_Folder_38C48(bpy.types.Operator):
    bl_idname = "sna.rafiki_create_folder_38c48"
    bl_label = "Rafiki Create Folder"
    bl_description = "Use this to Create a Folder"
    bl_options = {"REGISTER", "UNDO"}
    bl_property = 'sna_rafiki_sub_folder_name'
    sna_rafiki_sub_folder_directory: bpy.props.StringProperty(name='Rafiki Sub Folder Directory', description='Let rafiki create a new sub folder', default='', subtype='DIR_PATH', maxlen=0)
    sna_rafiki_sub_folder_name: bpy.props.StringProperty(name='Rafiki Sub Folder Name', description='', default='', subtype='NONE', maxlen=0)
    sna_browse_again: bpy.props.BoolProperty(name='Browse Again', description='', default=False)
    sna_use_popup: bpy.props.BoolProperty(name='Use Popup', description='', default=True)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(self.sna_rafiki_sub_folder_name):
            folder_path = bpy.path.abspath(os.path.join(self.sna_rafiki_sub_folder_directory,self.sna_rafiki_sub_folder_name))
            create_folder(folder_path)
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
            if self.sna_browse_again:
                bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder
            self.report({'INFO'}, message='🐒 Rafiki: sub folder ' + self.sna_rafiki_sub_folder_name + ' created')
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        if self.sna_use_popup:
            layout.prop(self, 'sna_rafiki_sub_folder_name', text='Sub Folder Name', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=500)


class SNA_OT_Rafiki_Create_Project_Folder_384C7(bpy.types.Operator):
    bl_idname = "sna.rafiki_create_project_folder_384c7"
    bl_label = "Rafiki Create Project Folder"
    bl_description = "Create the Rafiki Project Folder"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder):
            if os.path.isdir(os.path.dirname(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder)):
                folder_path = bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder)
                create_folder(folder_path)
                if bpy.context and bpy.context.screen:
                    for a in bpy.context.screen.areas:
                        a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Use_File_Browser_D2F47(bpy.types.Operator):
    bl_idname = "sna.rafiki_use_file_browser_d2f47"
    bl_label = "Rafiki Use File Browser"
    bl_description = "Use the File Browser"
    bl_options = {"REGISTER", "UNDO"}
    sna_path: bpy.props.StringProperty(name='Path', description='Path to File', default='', subtype='FILE_PATH', maxlen=0)
    sna_apply_filter: bpy.props.BoolProperty(name='Apply Filter', description='Filter File', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.path.abspath(self.sna_path)):
            sna_fn_set_file_browser_path_072AE(bpy.path.abspath(self.sna_path), self.sna_apply_filter)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_set_file_browser_path_072AE(path, filter):
    g_op_file_browser['sna_var_temp_byte_string_path'] = ''
    g_op_file_browser['sna_var_temp_byte_string_path'] = (bpy.path.abspath(path) if os.path.isdir(bpy.path.abspath(path)) else os.path.dirname(bpy.path.abspath(path)))
    if bool(find_areas_of_type(bpy.context.screen, 'FILE_BROWSER')):
        if (find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').ui_type == 'FILES'):
            find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').spaces[0].params.directory = bpy.path.abspath(g_op_file_browser['sna_var_temp_byte_string_path']).encode() 

            def delayed_A7118():
                if filter:
                    if os.path.isdir(path):
                        find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').spaces[0].params.filter_search = ''
                    else:
                        find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').spaces[0].params.filter_search = os.path.basename(path)
                else:
                    find_biggest_area_by_type(bpy.context.screen, 'FILE_BROWSER').spaces[0].params.filter_search = ''
            bpy.app.timers.register(delayed_A7118, first_interval=0.10000000149011612)
        else:
            sna_new_file_browser_window_resizable_097C1(1024, 512, True, g_op_file_browser['sna_var_temp_byte_string_path'], False)

            def delayed_E92EF():
                if filter:
                    if os.path.isdir(path):
                        bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = ''
                    else:
                        bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = os.path.basename(path)
                else:
                    bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = ''
            bpy.app.timers.register(delayed_E92EF, first_interval=0.10000000149011612)
    else:
        sna_new_file_browser_window_resizable_097C1(1024, 512, True, g_op_file_browser['sna_var_temp_byte_string_path'], False)

        def delayed_AFD62():
            if filter:
                if os.path.isdir(path):
                    bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = ''
                else:
                    bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = os.path.basename(path)
            else:
                bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.filter_search = ''
        bpy.app.timers.register(delayed_AFD62, first_interval=0.10000000149011612)


class SNA_OT_Rafiki_Go_Back_To_Project_Folder_Dab79(bpy.types.Operator):
    bl_idname = "sna.rafiki_go_back_to_project_folder_dab79"
    bl_label = "Rafiki Go Back to Project Folder"
    bl_description = "Return to the Project Folder"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder
        self.report({'INFO'}, message='🐒 Rafiki: ' + 'Project Folder ' + bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Import_File__629Ef(bpy.types.Operator):
    bl_idname = "sna.rafiki_import_file__629ef"
    bl_label = "Rafiki Import File "
    bl_description = "Import file based on extension"
    bl_options = {"REGISTER", "UNDO"}
    sna_path: bpy.props.StringProperty(name='path', description='Path to the Importable File', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.path.abspath(self.sna_path)):
            sna_fn_import_file_E65CE(bpy.path.abspath(self.sna_path))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_import_file_E65CE(Input):
    g_op_import_file['sna_var_temp_file_path'] = ''
    g_op_import_file['sna_var_temp_file_path'] = bpy.path.abspath(Input)
    if (os.path.splitext(bpy.path.abspath(Input))[1] == '.dae'):
        bpy.ops.wm.collada_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
    else:
        if (os.path.splitext(bpy.path.abspath(Input))[1] == '.abc'):
            bpy.ops.wm.alembic_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
        else:
            if (os.path.splitext(bpy.path.abspath(Input))[1] == '.usdc'):
                bpy.ops.wm.usd_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
            else:
                if (os.path.splitext(bpy.path.abspath(Input))[1] == '.usdz'):
                    bpy.ops.wm.usd_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                else:
                    if (os.path.splitext(bpy.path.abspath(Input))[1] == '.svg'):
                        bpy.ops.wm.gpencil_import_svg('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                    else:
                        if (os.path.splitext(bpy.path.abspath(Input))[1] == '.obj'):
                            bpy.ops.wm.obj_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                        else:
                            if (os.path.splitext(bpy.path.abspath(Input))[1] == '.ply'):
                                bpy.ops.wm.ply_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                            else:
                                if (os.path.splitext(bpy.path.abspath(Input))[1] == '.stl'):
                                    bpy.ops.wm.stl_import('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                else:
                                    if (os.path.splitext(bpy.path.abspath(Input))[1] == '.bvh'):
                                        bpy.ops.import_anim.bvh('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                    else:
                                        if (os.path.splitext(bpy.path.abspath(Input))[1] == '.fbx'):
                                            bpy.ops.import_scene.fbx('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                        else:
                                            if (os.path.splitext(bpy.path.abspath(Input))[1] == '.glb'):
                                                bpy.ops.import_scene.gltf('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                            else:
                                                if (os.path.splitext(bpy.path.abspath(Input))[1] == '.gltf'):
                                                    bpy.ops.import_scene.gltf('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                                else:
                                                    if (os.path.splitext(bpy.path.abspath(Input))[1] == '.x3d'):
                                                        bpy.ops.import_scene.x3d('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                                    else:
                                                        if (os.path.splitext(bpy.path.abspath(Input))[1] == '.wrl'):
                                                            bpy.ops.import_scene.x3d('INVOKE_DEFAULT', filepath=bpy.path.abspath(Input))
                                                        else:
                                                            if (os.path.splitext(bpy.path.abspath(Input))[1] == '.zip'):
                                                                bpy.ops.wm.call_menu('INVOKE_DEFAULT', name='MT_MT_ZIP_File_Import_Override')


class MT_MT_ZIP_File_Import_Override(bpy.types.Menu):
    bl_idname = "MT_MT_ZIP_File_Import_Override"
    bl_label = "Import .zip File"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=5)
        layout.operator_context = "INVOKE_DEFAULT"
        col_BB56F = layout.column(heading='', align=True)
        col_BB56F.alert = False
        col_BB56F.enabled = True
        col_BB56F.active = True
        col_BB56F.use_property_split = True
        col_BB56F.use_property_decorate = False
        col_BB56F.scale_x = 1.0
        col_BB56F.scale_y = 1.0
        col_BB56F.alignment = 'Expand'.upper()
        col_BB56F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_BB56F.operator('import_image.to_plane', text='Import Images as Planes', icon_value=166, emboss=True, depress=False)
        op.directory = os.path.dirname(g_op_import_file['sna_var_temp_file_path'])
        op = col_BB56F.operator('preferences.addon_install', text='Install .zip as addon', icon_value=698, emboss=True, depress=False)
        op.filepath = g_op_import_file['sna_var_temp_file_path']
        op.filter_glob = '.zip'


class SNA_OT_Rafiki_Import_Image_2A0A7(bpy.types.Operator):
    bl_idname = "sna.rafiki_import_image_2a0a7"
    bl_label = "Rafiki Import Image"
    bl_description = "Import Image in a variety of ways"
    bl_options = {"REGISTER", "UNDO"}
    sna_path: bpy.props.StringProperty(name='Path', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.path.abspath(self.sna_path)):
            sna_fn_import_image_as_68A5D(bpy.path.abspath(self.sna_path))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_import_image_as_68A5D(path):
    g_op_import_image['sna_var_temp_image_path'] = ''
    g_op_import_image['sna_var_temp_image_path'] = path
    bpy.ops.wm.call_menu('INVOKE_DEFAULT', name='MT_MT_Import_Image_As_Name_Override')


class MT_MT_Import_Image_As_Name_Override(bpy.types.Menu):
    bl_idname = "MT_MT_Import_Image_As_Name_Override"
    bl_label = "Import Image As"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=5)
        layout.operator_context = "INVOKE_DEFAULT"
        col_D14F6 = layout.column(heading='', align=True)
        col_D14F6.alert = False
        col_D14F6.enabled = True
        col_D14F6.active = True
        col_D14F6.use_property_split = True
        col_D14F6.use_property_decorate = False
        col_D14F6.scale_x = 1.0
        col_D14F6.scale_y = 1.0
        col_D14F6.alignment = 'Expand'.upper()
        col_D14F6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_D14F6.operator('object.load_reference_image', text='Reference Image', icon_value=363, emboss=True, depress=False)
        op.filepath = g_op_import_image['sna_var_temp_image_path']
        op.filter_image = True
        op = col_D14F6.operator('object.load_background_image', text='Background', icon_value=362, emboss=True, depress=False)
        op.filepath = g_op_import_image['sna_var_temp_image_path']
        op.filter_image = True
        op = col_D14F6.operator('image.open', text='Image Texture', icon_value=696, emboss=False, depress=False)
        op.filepath = g_op_import_image['sna_var_temp_image_path']
        op.filter_image = True
        op = col_D14F6.operator('import_image.to_plane', text='Images as Planes', icon_value=80, emboss=True, depress=False)
        op.directory = os.path.dirname(g_op_import_image['sna_var_temp_image_path'])
        op.filter_image = True


class SNA_OT_Rafiki_Import_Video_7371F(bpy.types.Operator):
    bl_idname = "sna.rafiki_import_video_7371f"
    bl_label = "Rafiki Import Video"
    bl_description = "Import Video File"
    bl_options = {"REGISTER", "UNDO"}
    sna_path: bpy.props.StringProperty(name='Path', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.path.abspath(self.sna_path)):
            sna_fn_import_video_file_0EDAA(bpy.path.abspath(self.sna_path))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_import_video_file_0EDAA(path):
    g_op_import_video['sna_var_temp_file_path'] = ''
    g_op_import_video['sna_var_temp_file_path'] = path
    bpy.ops.wm.call_menu('INVOKE_DEFAULT', name='MT_MT_Import_Video_Override')


class MT_MT_Import_Video_Override(bpy.types.Menu):
    bl_idname = "MT_MT_Import_Video_Override"
    bl_label = "Import Video"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=5)
        layout.operator_context = "INVOKE_DEFAULT"
        col_BB052 = layout.column(heading='', align=True)
        col_BB052.alert = False
        col_BB052.enabled = True
        col_BB052.active = True
        col_BB052.use_property_split = True
        col_BB052.use_property_decorate = False
        col_BB052.scale_x = 1.0
        col_BB052.scale_y = 1.0
        col_BB052.alignment = 'Expand'.upper()
        col_BB052.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_BB052.operator('object.load_reference_image', text='Video as Ref Image', icon_value=183, emboss=True, depress=False)
        op.filepath = g_op_import_video['sna_var_temp_file_path']
        op.filter_movie = True
        op = col_BB052.operator('object.load_background_image', text='Video as Background', icon_value=362, emboss=True, depress=False)
        op.filepath = g_op_import_video['sna_var_temp_file_path']
        op.filter_movie = True
        op = col_BB052.operator('sequencer.movie_strip_add', text='Video into VSE', icon_value=111, emboss=True, depress=False)
        op.filepath = g_op_import_video['sna_var_temp_file_path']
        op.filter_movie = True


def sna_new_window_resizable_5AAD0(Width, Height, Window_Type):
    g_op_new_temp_file_browser['sna_temp_render_slot_name'] = ''
    g_op_new_temp_file_browser['sna_temp_render_x'] = 0
    g_op_new_temp_file_browser['sna_temp_render_y'] = 0
    g_op_new_temp_file_browser['sna_temp_render_display'] = ''
    g_op_new_temp_file_browser['sna_temp_render_x'] = bpy.context.scene.render.resolution_x
    g_op_new_temp_file_browser['sna_temp_render_y'] = bpy.context.scene.render.resolution_y
    g_op_new_temp_file_browser['sna_temp_render_display'] = bpy.context.preferences.view.render_display_type
    bpy.context.scene.render.resolution_x = Width
    bpy.context.scene.render.resolution_y = Height
    bpy.context.preferences.view.render_display_type = 'WINDOW'
    if (property_exists("bpy.data.images", globals(), locals()) and 'Render Result' in bpy.data.images):
        g_op_new_temp_file_browser['sna_temp_render_slot_name'] = bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active.name
        g_op_new_temp_file_browser['sna_render_slot_exists'] = False
        for i_9397A in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
            if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_9397A].name == 'new_window'):
                g_op_new_temp_file_browser['sna_render_slot_exists'] = True
                bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_9397A]
                break
        if g_op_new_temp_file_browser['sna_render_slot_exists']:
            pass
        else:
            result_078C2 = bpy.data.images[bpy.data.images.find('Render Result')].render_slots.new(name='new_window', )
            bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = result_078C2
    bpy.ops.render.opengl('INVOKE_DEFAULT', )
    bpy.context.scene.render.resolution_x = g_op_new_temp_file_browser['sna_temp_render_x']
    bpy.context.scene.render.resolution_y = g_op_new_temp_file_browser['sna_temp_render_y']
    bpy.context.preferences.view.render_display_type = g_op_new_temp_file_browser['sna_temp_render_display']
    if Window_Type == "3D View":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'VIEW_3D'
    elif Window_Type == "Image Editor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'IMAGE_EDITOR'
    elif Window_Type == "UV Editor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'UV'
    elif Window_Type == "Compositor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'CompositorNodeTree'
    elif Window_Type == "Texture Nodes":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'TextureNodeTree'
    elif Window_Type == "Scripting Nodes":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'ScriptingNodesTree'
    elif Window_Type == "Geometry Nodes":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'GeometryNodeTree'
    elif Window_Type == "Shader Nodes":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'ShaderNodeTree'
    elif Window_Type == "Video Sequencer":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'SEQUENCE_EDITOR'
    elif Window_Type == "Clip Editor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'CLIP_EDITOR'
    elif Window_Type == "Dopesheet":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'DOPESHEET'
    elif Window_Type == "Timeline":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'TIMELINE'
    elif Window_Type == "F Curves":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'FCURVES'
    elif Window_Type == "Drivers":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'DRIVERS'
    elif Window_Type == "NLA Editor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'NLA_EDITOR'
    elif Window_Type == "Text Editor":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'TEXT_EDITOR'
    elif Window_Type == "Console":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'CONSOLE'
    elif Window_Type == "Info":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'INFO'
    elif Window_Type == "Outliner":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'OUTLINER'
    elif Window_Type == "Properties":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'PROPERTIES'
    elif Window_Type == "Files":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'FILES'
    elif Window_Type == "Assets":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'ASSETS'
    elif Window_Type == "Spreadhseet":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'SPREADSHEET'
    elif Window_Type == "Preferences":
        bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'PREFERENCES'
    else:
        pass
    if (property_exists("bpy.data.images", globals(), locals()) and 'Render Result' in bpy.data.images):
        if bool(g_op_new_temp_file_browser['sna_temp_render_slot_name']):
            g_op_new_temp_file_browser['sna_render_slot_exists'] = False
            for i_A334D in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
                if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_A334D].name == g_op_new_temp_file_browser['sna_temp_render_slot_name']):
                    g_op_new_temp_file_browser['sna_render_slot_exists'] = True
                    bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_A334D]
                    break
            if g_op_new_temp_file_browser['sna_render_slot_exists']:
                pass
            else:
                for i_5C200 in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
                    if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_5C200].name == 'Slot 1'):
                        bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_5C200]
                        break
    return bpy.context.window_manager.windows[-1]


def sna_new_file_browser_window_resizable_097C1(Width, Height, Use_Directory, Directory, Show_Toolbar):
    g_op_new_temp_file_browser['sna_temp_render_x'] = 0
    g_op_new_temp_file_browser['sna_temp_render_y'] = 0
    g_op_new_temp_file_browser['sna_temp_render_display'] = ''
    g_op_new_temp_file_browser['sna_temp_render_x'] = bpy.context.scene.render.resolution_x
    g_op_new_temp_file_browser['sna_temp_render_y'] = bpy.context.scene.render.resolution_y
    g_op_new_temp_file_browser['sna_temp_render_display'] = bpy.context.preferences.view.render_display_type
    bpy.context.scene.render.resolution_x = Width
    bpy.context.scene.render.resolution_y = Height
    bpy.context.preferences.view.render_display_type = 'WINDOW'
    if (property_exists("bpy.data.images", globals(), locals()) and 'Render Result' in bpy.data.images):
        g_op_new_temp_file_browser['sna_temp_render_slot_name'] = bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active.name
        g_op_new_temp_file_browser['sna_render_slot_exists'] = False
        for i_3E436 in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
            if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_3E436].name == 'new_window'):
                g_op_new_temp_file_browser['sna_render_slot_exists'] = True
                bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_3E436]
                break
        if g_op_new_temp_file_browser['sna_render_slot_exists']:
            pass
        else:
            result_EF8C3 = bpy.data.images[bpy.data.images.find('Render Result')].render_slots.new(name='new_window', )
            bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = result_EF8C3
    bpy.ops.render.opengl('INVOKE_DEFAULT', )
    bpy.context.scene.render.resolution_x = g_op_new_temp_file_browser['sna_temp_render_x']
    bpy.context.scene.render.resolution_y = g_op_new_temp_file_browser['sna_temp_render_y']
    bpy.context.preferences.view.render_display_type = g_op_new_temp_file_browser['sna_temp_render_display']
    bpy.context.window_manager.windows[-1].screen.areas[0].ui_type = 'FILES'

    def delayed_7E1B8():
        if Use_Directory:
            if os.path.exists(bpy.path.abspath(Directory)):
                bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].params.directory = bpy.path.abspath(Directory).encode() 
        bpy.context.window_manager.windows[-1].screen.areas[0].spaces[0].show_region_toolbar = Show_Toolbar
        if (property_exists("bpy.data.images", globals(), locals()) and 'Render Result' in bpy.data.images):
            if bool(g_op_new_temp_file_browser['sna_temp_render_slot_name']):
                g_op_new_temp_file_browser['sna_render_slot_exists'] = False
                for i_0D88E in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
                    if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_0D88E].name == g_op_new_temp_file_browser['sna_temp_render_slot_name']):
                        g_op_new_temp_file_browser['sna_render_slot_exists'] = True
                        bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_0D88E]
                        break
                if g_op_new_temp_file_browser['sna_render_slot_exists']:
                    pass
                else:
                    for i_BEC98 in range(len(bpy.data.images[bpy.data.images.find('Render Result')].render_slots)):
                        if (bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_BEC98].name == 'Slot 1'):
                            bpy.data.images[bpy.data.images.find('Render Result')].render_slots.active = bpy.data.images[bpy.data.images.find('Render Result')].render_slots[i_BEC98]
                            break
    bpy.app.timers.register(delayed_7E1B8, first_interval=0.05000000074505806)


class SNA_OT_Rafiki_Open_Blend_File_Fbd71(bpy.types.Operator):
    bl_idname = "sna.rafiki_open_blend_file_fbd71"
    bl_label = "Rafiki Open Blend File"
    bl_description = "Opens a Blend File"
    bl_options = {"REGISTER", "UNDO"}
    sna_path: bpy.props.StringProperty(name='path', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.path.abspath(self.sna_path)):
            bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(self.sna_path))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Open_Folder_2F93B(bpy.types.Operator):
    bl_idname = "sna.rafiki_open_folder_2f93b"
    bl_label = "Rafiki Open Folder"
    bl_description = "Rafiki Open Folder"
    bl_options = {"REGISTER", "UNDO"}
    sna_folder_path: bpy.props.StringProperty(name='folder path', description='', options={'HIDDEN'}, default='', subtype='DIR_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        directory = bpy.path.abspath(self.sna_folder_path)
        open_directory(directory)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_22387(bpy.types.Operator):
    bl_idname = "sna.rafiki_22387"
    bl_label = "Rafiki"
    bl_description = "Create a Rafiki Base Project"
    bl_options = {"REGISTER", "UNDO"}
    sna_base_folder: bpy.props.StringProperty(name='Base Folder', description='', default='', subtype='DIR_PATH', maxlen=0)
    sna_project_name: bpy.props.StringProperty(name='Project Name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = os.path.join(self.sna_base_folder,self.sna_project_name)
        bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder = os.path.join(self.sna_base_folder,self.sna_project_name)
        bpy.ops.sna.rafiki_create_project_folder_384c7('INVOKE_DEFAULT', )
        bpy.ops.sna.rafiki_refresh_project_folder_af53a('INVOKE_DEFAULT', )
        self.report({'INFO'}, message='🐒 Rafiki: project folder ' + os.path.basename(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder) + ' created')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_With_Popup_925Ac(bpy.types.Operator):
    bl_idname = "sna.rafiki_with_popup_925ac"
    bl_label = "Rafiki with Popup"
    bl_description = "Create a Rafiki Base Project"
    bl_options = {"REGISTER", "UNDO"}
    bl_property = 'sna_project_name'
    sna_base_folder: bpy.props.StringProperty(name='Base Folder', description='', default='', subtype='DIR_PATH', maxlen=0)
    sna_project_name: bpy.props.StringProperty(name='Project Name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sna.rafiki_22387('INVOKE_DEFAULT', sna_base_folder=self.sna_base_folder, sna_project_name=self.sna_project_name)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'sna_project_name', text='Project Name', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Rafiki_Refresh_Project_Folder_Af53A(bpy.types.Operator):
    bl_idname = "sna.rafiki_refresh_project_folder_af53a"
    bl_label = "Rafiki Refresh Project Folder"
    bl_description = "Refresh changes to the project (helps if item is missing or has been renamed)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rafiki_Set_Current_Folder_A8Da7(bpy.types.Operator):
    bl_idname = "sna.rafiki_set_current_folder_a8da7"
    bl_label = "Rafiki Set Current Folder"
    bl_description = "Set the Rafiki Project Folder"
    bl_options = {"REGISTER", "UNDO"}
    sna_rafiki_update_project_folder_path: bpy.props.StringProperty(name='Rafiki Update Project Folder Path', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)
    sna_go_up_a_folder: bpy.props.BoolProperty(name='Go Up a Folder', description='Choose whether to go up a folder or not', options={'HIDDEN'}, default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(self.sna_rafiki_update_project_folder_path):
            if os.path.exists(self.sna_rafiki_update_project_folder_path):
                bpy.context.scene.sna_active_project_collection_index = -1
                bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder = (os.path.dirname(self.sna_rafiki_update_project_folder_path) if self.sna_go_up_a_folder else self.sna_rafiki_update_project_folder_path)
                self.report({'INFO'}, message='🐒 Rafiki: Folder is now ' + bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)
        else:
            self.report({'WARNING'}, message='🐒 Rafiki: Please save your blend file first')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_0C770(bpy.types.AddonPreferences):
    bl_idname = 'rafiki'
    sna_current_folder: bpy.props.StringProperty(name='Current Folder', description='Current Folder in Rafiki Project', default='', subtype='DIR_PATH', maxlen=0, update=sna_update_sna_current_folder_B9271)
    sna_rafiki_projects_folder: bpy.props.StringProperty(name='Rafiki Projects Folder', description='Base Folder in Rafiki Project', default='', subtype='DIR_PATH', maxlen=0, update=sna_update_sna_rafiki_projects_folder_28569)
    sna_rafiki_project_name: bpy.props.StringProperty(name='Rafiki Project Name', description='The name of your project', default='Rafiki', subtype='NONE', maxlen=0)
    sna_rafiki_project_folder: bpy.props.StringProperty(name='Rafiki Project Folder', description='Rafiki Project Folder (Base Folder + Project Name)', default='', subtype='DIR_PATH', maxlen=0)
    sna_sub_folder_spacing: bpy.props.FloatProperty(name='Sub Folder Spacing', description='', default=1.0, subtype='NONE', unit='NONE', min=0.10000000149011612, max=1.0, step=1, precision=1)
    sna_rafiki_browser_rows: bpy.props.IntProperty(name='Rafiki Browser Rows', description='', default=0, subtype='NONE', min=0, soft_max=50)
    sna_rafiki_projects: bpy.props.CollectionProperty(name='Rafiki Projects', description='', type=bpy.types.PropertyGroup.__subclasses__()[0])
    sna_rafiki_projects_collection_index: bpy.props.IntProperty(name='Rafiki Projects Collection Index', description='', default=0, subtype='NONE')
    sna_rafiki_filter_file_browser: bpy.props.BoolProperty(name='Rafiki Filter File Browser', description='Filter File Browser when clicking on file name', default=False)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout_function = layout
            sna_ui_fn_prefs_ui_79755(layout_function, )


from pathlib import Path
#Initial Variables
#multi-line list
g_scripts['sna_image_ext_list'] = ['.bmp',
'.sgi',
'.rgb',
'.bw',
'.png',
'.jpg',
'.jpeg',
'.jp2',
'.j2c',
'.tga',
'.cin',
'.dpx',
'.exr',
'.hdr',
'.tif',
'.tiff',
'.webp',
]
g_scripts['sna_video_ext_list'] = ['mpg',
'.mpeg',
'.dvd',
'.vob',
'.mp4',
'.avi',
'.mov',
'.dv',
'.ogg',
'.ogv',
'.mkv',
'.flv',
'.webm'
]


g_scripts['sna_importable_ext_list'] = ['.abc',
'.dae',
'.usdc',
'.usdz',
'.obj',
'.ply',
'.stl',
'.bvh',
'.svg',
'.fbx',
'.glb',
'.gltf',
'.x3d',
'.wrl',
'.zip'
]


def create_folder(folder_path):
    path = Path(folder_path)
    path.mkdir(parents=True, exist_ok=True)


def open_directory(directory_path):
    pathlib_path = Path(directory_path)
    os.startfile(pathlib_path)


def rename_folder(directory_path, new_name):
    abs_old_path = os.path.abspath(directory_path)
    abs_new_path = os.path.join(os.path.dirname(abs_old_path),new_name)
    os.rename(abs_old_path, abs_new_path)
    return abs_new_path


def copy_folder_directory(source_dir,destination_dir):
    path_source_dir = Path(source_dir)
    path_dest_dir = Path(destination_dir)
    try:
        shutil.copytree(path_source_dir,path_dest_dir)
    except Exception as e:
        print(e)

    def defer():
        params = area.spaces.active.params
        if not params:
            print("still looking for params")
            return 0
        try:
            params.directory = directory
            print(f'The directory is set to {params.directory}')
        except Exception as e:
            print(e)
    if not bpy.app.timers.is_registered(defer):
        bpy.app.timers.register(defer)


#    for area in screen.areas:
#        for space in area.spaces:
#            if hasattr(space,'params'):
#                print(space.params)
#                if hasattr(space.params,'directory'):
#                    print(space.params.directory)
#                else:
#                    print(f'No directory param listed at the screen.areas.spaces level {area}.{space}')
#    if hasattr(screen,'params'):
#        print(screen.params)
#        if hasattr(screen.params,'directory'):
#            print(screen.params.directory)
#        else:
#            print('No directory param listed at the screens level')
#    print(f'No params property exists for this screen {screen}')


def sna_ui_fn_blank_labels_B1431(layout_function, reps, use_rafiki_on_first, path_for_rafiki, is_directory, item):
    for i_4407C in range(int(reps + 1.0)):
        row_08DC8 = layout_function.row(heading='', align=True)
        row_08DC8.alert = False
        row_08DC8.enabled = True
        row_08DC8.active = True
        row_08DC8.use_property_split = True
        row_08DC8.use_property_decorate = False
        row_08DC8.scale_x = bpy.context.preferences.addons['rafiki'].preferences.sna_sub_folder_spacing
        row_08DC8.scale_y = 1.0
        row_08DC8.alignment = 'Expand'.upper()
        row_08DC8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if ((i_4407C == 0) and use_rafiki_on_first):
            if os.path.isdir(path_for_rafiki):
                op = row_08DC8.operator('sna.rafiki_set_current_folder_a8da7', text='', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=False, depress=False)
                op.sna_rafiki_update_project_folder_path = path_for_rafiki
                op.sna_go_up_a_folder = False
            else:
                op = row_08DC8.operator('sna.rafiki_set_current_folder_a8da7', text='', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=False, depress=False)
                op.sna_rafiki_update_project_folder_path = os.path.dirname(path_for_rafiki)
                op.sna_go_up_a_folder = False
        else:
            if (i_4407C == 0):
                row_08DC8.label(text='', icon_value=101)
            else:
                if is_directory:
                    if (i_4407C < reps):
                        row_08DC8.label(text='', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Sub Folder.png'))
                    else:
                        op = row_08DC8.operator('sna.rafiki_use_file_browser_d2f47', text='', icon_value=11, emboss=False, depress=True)
                        op.sna_path = path_for_rafiki
                        op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                else:
                    row_08DC8.label(text='', icon_value=(load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Sub Folder.png') if (i_4407C < reps) else 101))


def sna_ui_fn_display_collection_E4456(layout_function, ):
    if bpy.context.scene.sna_active_project_collection:
        col_CA7F6 = layout_function.column(heading='', align=True)
        col_CA7F6.alert = False
        col_CA7F6.enabled = True
        col_CA7F6.active = True
        col_CA7F6.use_property_split = True
        col_CA7F6.use_property_decorate = False
        col_CA7F6.scale_x = 1.0
        col_CA7F6.scale_y = 1.0
        col_CA7F6.alignment = 'Expand'.upper()
        col_CA7F6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('01EE6', locals())
        col_CA7F6.template_list('SNA_UL_display_collection_list_01EE6', coll_id, bpy.context.scene, 'sna_active_project_collection', bpy.context.scene, 'sna_active_project_collection_index', rows=bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_browser_rows)
        col_CA7F6.prop(bpy.context.scene, 'sna_active_project_filter', text='Filter Contents', icon_value=688, emboss=True)
        col_CA7F6.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_filter_file_browser', text='Filter File in Browser', icon_value=30, emboss=True)


def sna_ui_fn_diplay_collection_loop_item_117F9(layout_function, loop_item, item_index):
    if (item_index == bpy.context.scene.sna_active_project_collection_index):
        layout_function = layout_function
        sna_ui_fn_blank_labels_B1431(layout_function, int(len(loop_item.prefix) + 2.0), True, loop_item.folder_directory, os.path.isdir(loop_item.folder_directory), loop_item)
    else:
        layout_function = layout_function
        sna_ui_fn_blank_labels_B1431(layout_function, int(len(loop_item.prefix) + 2.0), False, loop_item.folder_directory, os.path.isdir(loop_item.folder_directory), loop_item)
    if os.path.exists(loop_item.folder_directory):
        if os.path.isdir(loop_item.folder_directory):
            row_DF202 = layout_function.row(heading='', align=False)
            row_DF202.alert = False
            row_DF202.enabled = True
            row_DF202.active = True
            row_DF202.use_property_split = False
            row_DF202.use_property_decorate = False
            row_DF202.scale_x = 1.0
            row_DF202.scale_y = 1.0
            row_DF202.alignment = 'Expand'.upper()
            row_DF202.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_DF202.operator('sna.rafiki_use_file_browser_d2f47', text='', icon_value=108, emboss=False, depress=True)
            op.sna_path = loop_item.folder_directory
            op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
            op = row_DF202.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
            op.sna_path = loop_item.folder_directory
            op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
            if (property_exists("bpy.context.preferences.filepaths.asset_libraries", globals(), locals()) and os.path.basename(bpy.path.abspath(loop_item.folder_directory)) in bpy.context.preferences.filepaths.asset_libraries):
                if (bpy.path.abspath(bpy.context.preferences.filepaths.asset_libraries[bpy.context.preferences.filepaths.asset_libraries.find(os.path.basename(bpy.path.abspath(loop_item.folder_directory)))].path) == bpy.path.abspath(loop_item.folder_directory)):
                    op = row_DF202.operator('sna.rafiki_select_asset_library_4acf6', text='', icon_value=256, emboss=False, depress=False)
                    op.sna_directory = bpy.path.abspath(loop_item.folder_directory)
                else:
                    op = row_DF202.operator('sna.rafiki_add_folder_to_asset_libraries_3271a', text='', icon_value=124, emboss=False, depress=False)
                    op.sna_directory = bpy.path.abspath(loop_item.folder_directory)
            else:
                op = row_DF202.operator('sna.rafiki_add_folder_to_asset_libraries_3271a', text='', icon_value=124, emboss=False, depress=False)
                op.sna_directory = bpy.path.abspath(loop_item.folder_directory)
            op = row_DF202.operator('sna.rafiki_create_folder_38c48', text='', icon_value=689, emboss=False, depress=False)
            op.sna_rafiki_sub_folder_directory = loop_item.folder_directory
            op.sna_rafiki_sub_folder_name = os.path.basename(loop_item.folder_directory) + ' Sub Folder'
            op.sna_browse_again = True
            op.sna_use_popup = True
        else:
            if loop_item.is_blend_file:
                if (bpy.data.filepath == loop_item.folder_directory):
                    op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=15, emboss=False, depress=True)
                    op.sna_path = loop_item.folder_directory
                    op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                    op = layout_function.operator('wm.save_mainfile', text='', icon_value=70, emboss=False, depress=False)
                else:
                    op = layout_function.operator('sna.rafiki_open_blend_file_fbd71', text='', icon_value=695, emboss=False, depress=False)
                    op.sna_path = loop_item.folder_directory
                    op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
                    op.sna_path = loop_item.folder_directory
                    op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                    layout_function.label(text='', icon_value=101)
            else:
                if loop_item.is_video_file:
                    op = layout_function.operator('sna.rafiki_import_video_7371f', text='', icon_value=697, emboss=False, depress=False)
                    op.sna_path = loop_item.folder_directory
                    op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
                    op.sna_path = loop_item.folder_directory
                    op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                    layout_function.label(text='', icon_value=101)
                else:
                    if loop_item.is_image_file:
                        op = layout_function.operator('sna.rafiki_import_image_2a0a7', text='', icon_value=696, emboss=False, depress=False)
                        op.sna_path = loop_item.folder_directory
                        op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
                        op.sna_path = loop_item.folder_directory
                        op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                        layout_function.label(text='', icon_value=101)
                    else:
                        if loop_item.is_importable_file:
                            op = layout_function.operator('sna.rafiki_import_file__629ef', text='', icon_value=706, emboss=False, depress=False)
                            op.sna_path = loop_item.folder_directory
                            op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
                            op.sna_path = loop_item.folder_directory
                            op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                            layout_function.label(text='', icon_value=101)
                        else:
                            if loop_item.is_other_file:
                                op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text='', icon_value=184, emboss=False, depress=True)
                                op.sna_path = loop_item.folder_directory
                                op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                                op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
                                op.sna_path = loop_item.folder_directory
                                op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
                                layout_function.label(text='', icon_value=101)
    else:
        op = layout_function.operator('sna.rafiki_refresh_project_folder_af53a', text='', icon_value=2, emboss=False, depress=False)
        op = layout_function.operator('sna.rafiki_use_file_browser_d2f47', text=os.path.basename(loop_item.folder_directory), icon_value=0, emboss=False, depress=True)
        op.sna_path = loop_item.folder_directory
        op.sna_apply_filter = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_filter_file_browser
        op = layout_function.operator('sna.rafiki_refresh_project_folder_af53a', text='', icon_value=2, emboss=False, depress=False)


def sna_fn_active_projects_filter_ED2A1(Input):
    return bpy.context.scene.sna_active_project_filter in Input.folder_name


def sna_ui_fn_prefs_ui_79755(layout_function, ):
    col_70BA3 = layout_function.column(heading='', align=True)
    col_70BA3.alert = False
    col_70BA3.enabled = True
    col_70BA3.active = True
    col_70BA3.use_property_split = True
    col_70BA3.use_property_decorate = False
    col_70BA3.scale_x = 1.0
    col_70BA3.scale_y = 1.0
    col_70BA3.alignment = 'Expand'.upper()
    col_70BA3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_70BA3.label(text='Pick a Folder Where Your Projects Live', icon_value=0)
    col_70BA3.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_projects_folder', text='Projects Folder', icon_value=0, emboss=True)
    col_70BA3.separator(factor=3.0)
    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder)):
        col_70BA3.label(text='Current Projects', icon_value=0)
        col_70BA3.label(text='Select an Existing Project Below', icon_value=0)
        coll_id = display_collection_id('B1951', locals())
        col_70BA3.template_list('SNA_UL_display_collection_list001_B1951', coll_id, bpy.context.scene, 'sna_rafiki_projects_collection', bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_projects_collection_index', rows=0)
    col_70BA3.prop(bpy.context.scene, 'sna_rafiki_projects_filter', text='Filter Projects', icon_value=688, emboss=True)
    col_70BA3.separator(factor=3.0)
    col_70BA3.label(text='New Projects', icon_value=0)
    col_70BA3.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_project_name', text='Project Name', icon_value=0, emboss=True)
    col_70BA3.label(text='Project Templates', icon_value=0)
    col_781C2 = col_70BA3.column(heading='', align=True)
    col_781C2.alert = False
    col_781C2.enabled = True
    col_781C2.active = True
    col_781C2.use_property_split = False
    col_781C2.use_property_decorate = False
    col_781C2.scale_x = 1.0
    col_781C2.scale_y = 1.0
    col_781C2.alignment = 'Expand'.upper()
    col_781C2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    coll_id = display_collection_id('D5355', locals())
    col_781C2.template_list('SNA_UL_display_collection_list_D5355', coll_id, bpy.context.scene, 'sna_template_projects_collection', bpy.context.scene, 'sna_template_projects_collection_index', rows=0)
    op = col_781C2.operator('sna.rafiki_copy_folder_and_create_rafiki_project_d48e1', text='Create Project From Default Template', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=True, depress=False)
    op.sna_source = os.path.dirname(os.path.join(os.path.dirname(__file__), 'assets', 'Film_Template'))
    op.sna_dest = os.path.join(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder,bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_name)
    op.sna_rafiki_project = os.path.join(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder,bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_name)
    op = col_781C2.operator('sna.rafiki_22387', text='Create Empty Project', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=True, depress=False)
    op.sna_base_folder = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_projects_folder
    op.sna_project_name = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_name
    col_781C2.separator(factor=1.0)
    col_70BA3.separator(factor=3.0)
    col_70BA3.label(text='Settings', icon_value=0)
    col_70BA3.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_browser_rows', text='Rafiki Browser Rows', icon_value=0, emboss=True)
    col_70BA3.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_rafiki_filter_file_browser', text='File Browser Filter Item', icon_value=30, emboss=True)


def sna_fn_display_projects_B0A0A(Input):
    return bpy.context.scene.sna_rafiki_projects_filter in Input.project_name


def sna_ui_fn_rafiki_browser_F4F2B(layout_function, ):
    if os.path.isdir(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder):
        col_E3F48 = layout_function.column(heading='', align=True)
        col_E3F48.alert = False
        col_E3F48.enabled = True
        col_E3F48.active = True
        col_E3F48.use_property_split = True
        col_E3F48.use_property_decorate = False
        col_E3F48.scale_x = 1.0
        col_E3F48.scale_y = 1.0
        col_E3F48.alignment = 'Expand'.upper()
        col_E3F48.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_E3F48.label(text='Current Folder', icon_value=0)
        row_17774 = col_E3F48.row(heading='', align=True)
        row_17774.alert = False
        row_17774.enabled = True
        row_17774.active = True
        row_17774.use_property_split = True
        row_17774.use_property_decorate = False
        row_17774.scale_x = 1.0
        row_17774.scale_y = 1.0
        row_17774.alignment = 'Expand'.upper()
        row_17774.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_17774.operator('sna.rafiki_go_back_to_project_folder_dab79', text='', icon_value=(692 if (bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder == bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder) else load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg')), emboss=True, depress=False)
        row_17774.prop(bpy.context.preferences.addons['rafiki'].preferences, 'sna_current_folder', text='', icon_value=0, emboss=True)
    layout_function.separator(factor=1.0)
    if bool(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder):
        if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)):
            col_9B1D0 = layout_function.column(heading='', align=True)
            col_9B1D0.alert = False
            col_9B1D0.enabled = True
            col_9B1D0.active = True
            col_9B1D0.use_property_split = True
            col_9B1D0.use_property_decorate = False
            col_9B1D0.scale_x = 1.0
            col_9B1D0.scale_y = 1.0
            col_9B1D0.alignment = 'Expand'.upper()
            col_9B1D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_6A45E = col_9B1D0.row(heading='', align=False)
            row_6A45E.alert = False
            row_6A45E.enabled = True
            row_6A45E.active = True
            row_6A45E.use_property_split = False
            row_6A45E.use_property_decorate = False
            row_6A45E.scale_x = 1.0
            row_6A45E.scale_y = 1.0
            row_6A45E.alignment = 'Left'.upper()
            row_6A45E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_6A45E.separator(factor=4.609999656677246)
            if (os.path.isdir(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder) and bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder in bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder and (bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder != bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)):
                op = row_6A45E.operator('sna.rafiki_set_current_folder_a8da7', text='', icon_value=690, emboss=False, depress=False)
                op.sna_rafiki_update_project_folder_path = bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)
                op.sna_go_up_a_folder = True
            else:
                if (bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder != bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder):
                    op = row_6A45E.operator('sna.rafiki_go_back_to_project_folder_dab79', text='', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg'), emboss=False, depress=False)
                    op = row_6A45E.operator('sna.rafiki_go_back_to_project_folder_dab79', text='Folder is outside of project', icon_value=0, emboss=False, depress=False)
                else:
                    row_6A45E.label(text='', icon_value=(load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki.svg') if (bpy.context.scene.sna_active_project_collection_index == -1) else 108))
            op = row_6A45E.operator('sna.rafiki_open_folder_2f93b', text=(os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)) + '' if (bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder == bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder) else os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)) + ''), icon_value=0, emboss=False, depress=False)
            op.sna_folder_path = bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)
            op = row_6A45E.operator('sna.rafiki_create_folder_38c48', text='', icon_value=689, emboss=False, depress=False)
            op.sna_rafiki_sub_folder_directory = bpy.path.abspath(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder)
            op.sna_rafiki_sub_folder_name = os.path.basename(bpy.context.preferences.addons['rafiki'].preferences.sna_current_folder) + ' Sub Folder'
            op.sna_browse_again = True
            op.sna_use_popup = True
            layout_function = col_9B1D0
            sna_ui_fn_display_collection_E4456(layout_function, )


class SNA_PT_rafiki_panel_view3d_5F649(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_rafiki_panel_view3d_5F649'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        if os.path.isdir(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder):
            op = layout.operator('sna.rafiki_open_folder_2f93b', text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'), emboss=False, depress=False)
            op.sna_folder_path = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder
        else:
            layout.label(text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'))

    def draw(self, context):
        layout = self.layout


class SNA_PT_rafiki_panel_vse_ACD2E(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_rafiki_panel_vse_ACD2E'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOLS'
    bl_context = ''
    bl_category = 'Rafiki'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        if os.path.isdir(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder):
            op = layout.operator('sna.rafiki_open_folder_2f93b', text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'), emboss=False, depress=False)
            op.sna_folder_path = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder
        else:
            layout.label(text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'))

    def draw(self, context):
        layout = self.layout


class SNA_PT_rafiki_panel_serpens_34DC9(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_rafiki_panel_serpens_34DC9'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.label(text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'))

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_rafiki_browser_F4F2B(layout_function, )


class SNA_PT_rafiki_panel_vse_F663D(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_rafiki_panel_vse_F663D'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        if os.path.isdir(bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder):
            op = layout.operator('sna.rafiki_open_folder_2f93b', text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'), emboss=False, depress=False)
            op.sna_folder_path = bpy.context.preferences.addons['rafiki'].preferences.sna_rafiki_project_folder
        else:
            layout.label(text='Rafiki', icon_value=load_preview_icon(r'E:\Dev\Personal\Rafiki\Icons\Rafiki_2.svg'))

    def draw(self, context):
        layout = self.layout


def sna_add_to_wm_mt_splash_6CBBC(self, context):
    if not (False):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_rafiki_browser_F4F2B(layout_function, )


class SNA_PT_PROJECT_BROWSER_46694(bpy.types.Panel):
    bl_label = 'Project Browser'
    bl_idname = 'SNA_PT_PROJECT_BROWSER_46694'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_rafiki_panel_view3d_5F649'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_rafiki_browser_F4F2B(layout_function, )


class SNA_PT_PROJECT_SETUP_7FF5D(bpy.types.Panel):
    bl_label = 'Project Setup'
    bl_idname = 'SNA_PT_PROJECT_SETUP_7FF5D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_rafiki_panel_view3d_5F649'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_prefs_ui_79755(layout_function, )


class SNA_PT_PROJECT_BROWSER_8072B(bpy.types.Panel):
    bl_label = 'Project Browser'
    bl_idname = 'SNA_PT_PROJECT_BROWSER_8072B'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOLS'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_rafiki_panel_vse_ACD2E'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_rafiki_browser_F4F2B(layout_function, )


class SNA_PT_PROJECT_SETUP_8B590(bpy.types.Panel):
    bl_label = 'Project Setup'
    bl_idname = 'SNA_PT_PROJECT_SETUP_8B590'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOLS'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_rafiki_panel_vse_ACD2E'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_prefs_ui_79755(layout_function, )


class SNA_PT_PROJECT_BROWSER_B540B(bpy.types.Panel):
    bl_label = 'Project Browser'
    bl_idname = 'SNA_PT_PROJECT_BROWSER_B540B'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_rafiki_panel_vse_F663D'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_rafiki_browser_F4F2B(layout_function, )


class SNA_PT_PROJECT_SETUP_A8762(bpy.types.Panel):
    bl_label = 'Project Setup'
    bl_idname = 'SNA_PT_PROJECT_SETUP_A8762'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_rafiki_panel_vse_F663D'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_prefs_ui_79755(layout_function, )


class SNA_GROUP_sna_active_project_group(bpy.types.PropertyGroup):
    folder_name: bpy.props.StringProperty(name='Folder Name', description='Folder Name', default='', subtype='NONE', maxlen=0, update=sna_update_folder_name_9CB54)
    folder_directory: bpy.props.StringProperty(name='Folder Directory', description='Base Name of Folder', default='', subtype='DIR_PATH', maxlen=0)
    prefix: bpy.props.StringProperty(name='Prefix', description='Prefix for Item', default='', subtype='NONE', maxlen=0)
    condition_1: bpy.props.BoolProperty(name='Condition 1', description='Condition for Item', default=False)
    is_directory: bpy.props.BoolProperty(name='Is Directory', description='Is Item a Folder', default=False)
    is_blend_file: bpy.props.BoolProperty(name='Is Blend File', description='Is Item a Blend File', default=False)
    is_video_file: bpy.props.BoolProperty(name='Is Video File', description='Is Item a Video File', default=False)
    is_image_file: bpy.props.BoolProperty(name='Is Image File', description='Is Item an Image File', default=False)
    is_importable_file: bpy.props.BoolProperty(name='Is Importable File', description='Is the File Importable', default=False)
    is_other_file: bpy.props.BoolProperty(name='Is Other File', description='Is File an FBX', default=False)


class SNA_GROUP_sna_template_projects_group(bpy.types.PropertyGroup):
    template_project_name: bpy.props.StringProperty(name='Template Project Name', description='', default='', subtype='NONE', maxlen=0)


class SNA_GROUP_sna_rafiki_projects_group(bpy.types.PropertyGroup):
    project_name: bpy.props.StringProperty(name='Project Name', description='Name of the Project', default='', subtype='NONE', maxlen=0)
    project_folder: bpy.props.StringProperty(name='Project Folder', description='Project Folder Path', default='', subtype='DIR_PATH', maxlen=0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_active_project_group)
    bpy.utils.register_class(SNA_GROUP_sna_template_projects_group)
    bpy.utils.register_class(SNA_GROUP_sna_rafiki_projects_group)
    bpy.types.Scene.sna_folder_name = bpy.props.StringProperty(name='Folder Name', description='The Name of the Folder', default='Folder', subtype='NONE', maxlen=0, update=sna_update_folder_name_9CB54)
    bpy.types.Scene.sna_folder_location = bpy.props.StringProperty(name='Folder Location', description='', default='', subtype='DIR_PATH', maxlen=0)
    bpy.types.Scene.sna_active_project_collection = bpy.props.CollectionProperty(name='Active Project Collection', description='', type=SNA_GROUP_sna_active_project_group)
    bpy.types.Scene.sna_active_project_collection_index = bpy.props.IntProperty(name='Active Project Collection Index', description='Index of Collection', default=-1, subtype='NONE')
    bpy.types.Scene.sna_active_project_filter = bpy.props.StringProperty(name='Active Project Filter', description='Enter text to filter', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_template_projects_collection = bpy.props.CollectionProperty(name='Template Projects Collection', description='', type=SNA_GROUP_sna_template_projects_group)
    bpy.types.Scene.sna_template_projects_collection_index = bpy.props.IntProperty(name='Template Projects Collection Index', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_rafiki_projects_collection = bpy.props.CollectionProperty(name='Rafiki Projects Collection', description='Rafiki Projects', type=SNA_GROUP_sna_rafiki_projects_group)
    bpy.types.Scene.sna_rafiki_projects_filter = bpy.props.StringProperty(name='Rafiki Projects Filter', description='Enter text to filter', default='', subtype='NONE', maxlen=0)
    bpy.app.handlers.load_pre.append(load_pre_handler_1A3F2)
    bpy.utils.register_class(SNA_OT_Rafiki_Add_Folder_To_Asset_Libraries_3271A)
    bpy.utils.register_class(SNA_OT_Rafiki_Select_Asset_Library_4Acf6)
    bpy.utils.register_class(SNA_OT_Rafiki_Copy_Folder_2F5D3)
    bpy.utils.register_class(SNA_OT_Rafiki_Copy_Folder_And_Create_Rafiki_Project_D48E1)
    bpy.utils.register_class(SNA_OT_Rafiki_Create_Folder_38C48)
    bpy.utils.register_class(SNA_OT_Rafiki_Create_Project_Folder_384C7)
    bpy.utils.register_class(SNA_OT_Rafiki_Use_File_Browser_D2F47)
    bpy.utils.register_class(SNA_OT_Rafiki_Go_Back_To_Project_Folder_Dab79)
    bpy.utils.register_class(SNA_OT_Rafiki_Import_File__629Ef)
    bpy.utils.register_class(MT_MT_ZIP_File_Import_Override)
    bpy.utils.register_class(SNA_OT_Rafiki_Import_Image_2A0A7)
    bpy.utils.register_class(MT_MT_Import_Image_As_Name_Override)
    bpy.utils.register_class(SNA_OT_Rafiki_Import_Video_7371F)
    bpy.utils.register_class(MT_MT_Import_Video_Override)
    bpy.utils.register_class(SNA_OT_Rafiki_Open_Blend_File_Fbd71)
    bpy.utils.register_class(SNA_OT_Rafiki_Open_Folder_2F93B)
    bpy.utils.register_class(SNA_OT_Rafiki_22387)
    bpy.utils.register_class(SNA_OT_Rafiki_With_Popup_925Ac)
    bpy.utils.register_class(SNA_OT_Rafiki_Refresh_Project_Folder_Af53A)
    bpy.utils.register_class(SNA_OT_Rafiki_Set_Current_Folder_A8Da7)
    bpy.utils.register_class(SNA_AddonPreferences_0C770)
    bpy.utils.register_class(SNA_UL_display_collection_list_01EE6)
    bpy.utils.register_class(SNA_UL_display_collection_list001_B1951)
    bpy.utils.register_class(SNA_UL_display_collection_list_D5355)
    bpy.utils.register_class(SNA_PT_rafiki_panel_view3d_5F649)
    bpy.utils.register_class(SNA_PT_rafiki_panel_vse_ACD2E)
    bpy.utils.register_class(SNA_PT_rafiki_panel_serpens_34DC9)
    bpy.utils.register_class(SNA_PT_rafiki_panel_vse_F663D)
    bpy.types.WM_MT_splash.prepend(sna_add_to_wm_mt_splash_6CBBC)
    bpy.utils.register_class(SNA_PT_PROJECT_BROWSER_46694)
    bpy.utils.register_class(SNA_PT_PROJECT_SETUP_7FF5D)
    bpy.utils.register_class(SNA_PT_PROJECT_BROWSER_8072B)
    bpy.utils.register_class(SNA_PT_PROJECT_SETUP_8B590)
    bpy.utils.register_class(SNA_PT_PROJECT_BROWSER_B540B)
    bpy.utils.register_class(SNA_PT_PROJECT_SETUP_A8762)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_rafiki_projects_filter
    del bpy.types.Scene.sna_rafiki_projects_collection
    del bpy.types.Scene.sna_template_projects_collection_index
    del bpy.types.Scene.sna_template_projects_collection
    del bpy.types.Scene.sna_active_project_filter
    del bpy.types.Scene.sna_active_project_collection_index
    del bpy.types.Scene.sna_active_project_collection
    del bpy.types.Scene.sna_folder_location
    del bpy.types.Scene.sna_folder_name
    bpy.utils.unregister_class(SNA_GROUP_sna_rafiki_projects_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_template_projects_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_active_project_group)
    bpy.app.handlers.load_pre.remove(load_pre_handler_1A3F2)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Add_Folder_To_Asset_Libraries_3271A)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Select_Asset_Library_4Acf6)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Copy_Folder_2F5D3)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Copy_Folder_And_Create_Rafiki_Project_D48E1)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Create_Folder_38C48)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Create_Project_Folder_384C7)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Use_File_Browser_D2F47)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Go_Back_To_Project_Folder_Dab79)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Import_File__629Ef)
    bpy.utils.unregister_class(MT_MT_ZIP_File_Import_Override)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Import_Image_2A0A7)
    bpy.utils.unregister_class(MT_MT_Import_Image_As_Name_Override)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Import_Video_7371F)
    bpy.utils.unregister_class(MT_MT_Import_Video_Override)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Open_Blend_File_Fbd71)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Open_Folder_2F93B)
    bpy.utils.unregister_class(SNA_OT_Rafiki_22387)
    bpy.utils.unregister_class(SNA_OT_Rafiki_With_Popup_925Ac)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Refresh_Project_Folder_Af53A)
    bpy.utils.unregister_class(SNA_OT_Rafiki_Set_Current_Folder_A8Da7)
    bpy.utils.unregister_class(SNA_AddonPreferences_0C770)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_01EE6)
    bpy.utils.unregister_class(SNA_UL_display_collection_list001_B1951)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_D5355)
    bpy.utils.unregister_class(SNA_PT_rafiki_panel_view3d_5F649)
    bpy.utils.unregister_class(SNA_PT_rafiki_panel_vse_ACD2E)
    bpy.utils.unregister_class(SNA_PT_rafiki_panel_serpens_34DC9)
    bpy.utils.unregister_class(SNA_PT_rafiki_panel_vse_F663D)
    bpy.types.WM_MT_splash.remove(sna_add_to_wm_mt_splash_6CBBC)
    bpy.utils.unregister_class(SNA_PT_PROJECT_BROWSER_46694)
    bpy.utils.unregister_class(SNA_PT_PROJECT_SETUP_7FF5D)
    bpy.utils.unregister_class(SNA_PT_PROJECT_BROWSER_8072B)
    bpy.utils.unregister_class(SNA_PT_PROJECT_SETUP_8B590)
    bpy.utils.unregister_class(SNA_PT_PROJECT_BROWSER_B540B)
    bpy.utils.unregister_class(SNA_PT_PROJECT_SETUP_A8762)
